package loginTest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.LoginPage;
import resources.Base;

public class BlankFields extends Base {

	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  fieldValidation() throws IOException
	{

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		LoginPage lp = new LoginPage(driver);
		
		lp.getLoginButton().click();
		
		WebDriverWait  d = new WebDriverWait(driver, 15);
		d.until(ExpectedConditions.visibilityOf(lp.getPhoneEmailErrorMessage()));
		
		Assert.assertEquals(lp.getPhoneEmailErrorMessage().getText(), prop.getProperty("phoneEmailErrorMessage"));
		
		Assert.assertEquals(lp.getPasswordErrorMessage().getText(), prop.getProperty("passwordErrorMessage"));

		
		
		}
	

	}
	
	