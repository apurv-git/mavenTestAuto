package loginTest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObject.LoginPage;
import resources.Base;

public class IncorrectEmailOrPhoneNumber extends Base {

	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test(dataProvider="getData")
	public void  inccorentEmailValidation(String emailId, String password) throws IOException
	{
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		LoginPage lp = new LoginPage(driver);
				
		lp.getPhoneNumberOrEmailId().sendKeys(emailId);
		
		lp.getHiddenPassword().sendKeys(password);
		
		lp.getLoginButton().click();
		
		// Waiting for the No user Account Message Web Element
		WebDriverWait  d = new WebDriverWait(driver, 15);
		d.until(ExpectedConditions.visibilityOf(lp.getNoUserAccountFound()));
		
		//Checking No User Account Message
		Assert.assertEquals(lp.getNoUserAccountFound().getText(), prop.getProperty("noUserAccountMessage"));
	}
	
	@DataProvider
	public Object[][] getData()
	{

		Object[][] data = new Object[2][2];	
		
		//First Invalid email and valid password
		data[0][0] = "Hello@gmail.com";
		data[0][1] = "123455";
		
		//Second invalid Email and Valid Password
		data[1][0] = "hello2@gmail.com";
		data[1][1] = "Aman@12345";
	
		return data;
	}
	
	
	
}