package loginTest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.LoginPage;
import resources.Base;

public class AllFieldsDisplayedUI extends Base {	
	
	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  allFieldsPresent() throws IOException
	{

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		LoginPage lp = new LoginPage(driver);
		
		WebDriverWait  d = new WebDriverWait(driver, 15);
		d.until(ExpectedConditions.visibilityOf(lp.getPhoneNumberOrEmailId()));
		
		Assert.assertEquals(lp.getLoginPageHeading(), prop.getProperty("loginPageHeading"));
		
		Assert.assertTrue(lp.getHelplineLink().isDisplayed());
		
		Assert.assertTrue(lp.getPhoneNumberOrEmailId().isDisplayed());
		
		Assert.assertTrue(lp.getHiddenPassword().isDisplayed());

		Assert.assertTrue(lp.getForgotPasswordLink().isDisplayed());

		Assert.assertTrue(lp.getLoginFacebookButton().isDisplayed());

		Assert.assertTrue(lp.getLoginGoogleButton().isEnabled());

		}
	

	}
	
	