package loginTest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObject.LoginPage;
import resources.Base;

public class IncorrectPassword extends Base {

	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test(dataProvider="getData")
	public void  incorrectPasswordValidation(String emailId, String password) throws IOException
	{
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		LoginPage lp = new LoginPage(driver);
				
		lp.getPhoneNumberOrEmailId().sendKeys(emailId);
		
		lp.getHiddenPassword().sendKeys(password);
		
		lp.getLoginButton().click();
		
		// Waiting for the No user Account Message Web Element
		WebDriverWait  d = new WebDriverWait(driver, 15);
		d.until(ExpectedConditions.visibilityOf(lp.getNoUserAccountFound()));
		
		//Checking No User Account Message
		Assert.assertEquals(lp.getNoUserAccountFound().getText(), prop.getProperty("invalidCredentials"));
		
	}
	
	@DataProvider
	public Object[][] getData()
	{

		Object[][] data = new Object[2][2];	
		
		//First valid email and Invalid password
		data[0][0] = "apurvisbest@gmail.com";
		data[0][1] = "VFRCDE";
		
		//Second valid Email and InValid Password
		data[1][0] = "apurvisbest@gmail.com";
		data[1][1] = "GDH3454$$#";
	
		return data;
	}
	
	
	
}