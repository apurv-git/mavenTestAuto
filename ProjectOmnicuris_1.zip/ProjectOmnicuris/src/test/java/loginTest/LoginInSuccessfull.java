package loginTest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.LoginPage;
import resources.Base;

public class LoginInSuccessfull extends Base {

	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  successfullLoginValidation() throws IOException
	{

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		LoginPage lp = new LoginPage(driver);
				
		lp.getPhoneNumberOrEmailId().sendKeys(prop.getProperty("email"));
		
		lp.getHiddenPassword().sendKeys(prop.getProperty("password"));
		
		lp.getLoginButton().click();
		
		WebDriverWait  d = new WebDriverWait(driver, 15);
		d.until(ExpectedConditions.titleContains(prop.getProperty("afterLogInTitle")));
		
		Assert.assertEquals(driver.getTitle(), prop.getProperty("afterLogInTitle"));
		}


	}
	
	