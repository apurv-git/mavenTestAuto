package registrationTest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.RegistrationPage;
import resources.Base;

public class AllFieldValidation extends Base {

	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  fieldsValidation() throws IOException
	{

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		RegistrationPage rp = new RegistrationPage(driver);
				
		rp.getFirstName().sendKeys(prop.getProperty("invalidFirstName"));
		Assert.assertEquals(rp.getFirstNameErrorMessage().getText(), prop.getProperty("firstNameErrorMessage"));
		
		rp.getEmailId().sendKeys(prop.getProperty("invalidEmailId"));
		Assert.assertEquals(rp.getEmailIdErrorMessage().getText(), prop.getProperty("emailIdErrorMessage"));
		
		//Valid Email Id Validation Using Regex
		Assert.assertTrue(RegistrationPage.validate(prop.getProperty("validEmailID")));

		
		rp.getHiddenCreatePassword().sendKeys(prop.getProperty("invalidPassword"));
		Assert.assertEquals(rp.getHiddenCreatePasswordErrorMessage().getText(), prop.getProperty("hiddenCreatePasswordErrorMessage"));
		
		rp.getPolicyCheckBox().click();
		
		rp.getPolicyCheckBox().isSelected();
		
		rp.getMedicalCouncilDropDown().click();
		
		rp.getDropDwonOptionBihar().click();
		
		rp.getRegisterButton().click();
		
		Assert.assertEquals(rp.getLastNameErrorMessage().getText(), prop.getProperty("lastNameErrorMessage"));
		
		Assert.assertEquals(rp.getMedicalRegistrationNoErrorMessage().getText(), prop.getProperty("medicalRegistrationNoErrorMessage"));
		
		
		}
	
	}
	
	