package registrationTest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.RegistrationPage;
import resources.Base;

public class AllBlankFields extends Base {

	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  blankFieldsValidation() throws IOException
	{

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		RegistrationPage rp = new RegistrationPage(driver);
				
		rp.getRegisterButton().click();
		
		Assert.assertEquals(rp.getFirstNameErrorMessage().getText(), prop.getProperty("firstNameErrorMessage2"));
		
		Assert.assertEquals(rp.getLastNameErrorMessage().getText(), prop.getProperty("lastNameErrorMessage"));

		Assert.assertEquals(rp.getEmailIdErrorMessage().getText(), prop.getProperty("emailIdErrorMessage2"));

		Assert.assertEquals(rp.getMobileNumberErrorMessage().getText(), prop.getProperty("mobileNumberErrorMessage2"));

		Assert.assertEquals(rp.getHiddenCreatePasswordErrorMessage().getText(), prop.getProperty("hiddenCreatePasswordErrorMessage2"));

		Assert.assertEquals(rp.getMedicalRegistrationNoErrorMessage().getText(), prop.getProperty("medicalRegistrationNoErrorMessage"));
		
		}
	
	}
	
	