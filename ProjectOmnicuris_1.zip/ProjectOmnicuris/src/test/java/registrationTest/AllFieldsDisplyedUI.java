package registrationTest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.RegistrationPage;
import resources.Base;

public class AllFieldsDisplyedUI extends Base {

	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  fieldsDisplayed() throws IOException
	{

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		RegistrationPage rp = new RegistrationPage(driver);
				
		Assert.assertEquals(rp.getwelcomeMessage(), prop.getProperty("welcomeMessage"));
		
		Assert.assertTrue(rp.getFirstName().isDisplayed());
		
		Assert.assertTrue(rp.getEmailId().isDisplayed());
		
		Assert.assertTrue(rp.getMobileNumber().isEnabled());
		
		Assert.assertTrue(rp.getHiddenCreatePassword().isDisplayed());
		
		Assert.assertTrue(rp.getPolicyCheckBox().isDisplayed());
				
		Assert.assertTrue(rp.getMedicalCouncilDropDown().isDisplayed());
				
		Assert.assertTrue(rp.getRegisterButton().isDisplayed());
		
		Assert.assertTrue(rp.getCreatePasswordEye().isDisplayed());
		
		}

	}
	
	