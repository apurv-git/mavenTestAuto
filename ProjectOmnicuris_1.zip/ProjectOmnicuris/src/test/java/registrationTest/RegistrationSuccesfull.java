package registrationTest;

import java.io.IOException;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.RegistrationPage;
import resources.Base;

public class RegistrationSuccesfull extends Base {

	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  registerSuccesValidate() throws IOException
	{

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		RegistrationPage rp = new RegistrationPage(driver);
						
		rp.getFirstName().sendKeys(RegistrationPage.getAlphaNumericString(6));
		
		rp.getLastName().sendKeys(RegistrationPage.getAlphaNumericString(6));
		
		rp.getEmailId().sendKeys(RegistrationPage.getAlphaNumericString(6)+"@gmail.com");
		
		
        Random rand = new Random(); 
                
		rp.getMobileNumber().sendKeys(rand.nextInt(1000)+"1234567");
		
		rp.getHiddenCreatePassword().sendKeys(RegistrationPage.getAlphaNumericString(6)+"@12345");
		
		rp.getMedicalRegistrationNo().sendKeys(rand.nextInt(1000)+"23");
		
		rp.getPolicyCheckBox().click();
		
		rp.getPolicyCheckBox().isSelected();
		
		rp.getMedicalCouncilDropDown().click();
		
		rp.getDropDwonOptionBihar().click();
		
		rp.getRegisterButton().click();
		
		WebDriverWait  d = new WebDriverWait(driver, 15);
		d.until(ExpectedConditions.visibilityOf(rp.getOptBox()));
		
		rp.getOptBox().sendKeys("12345");
		
		rp.getVerifyButton().click();
		
		rp.getInvalidOtpMessage().isDisplayed();
		
		}

	
	}
	
	