package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	public WebDriver driver;
	
	//All the webElement Locators for the Login Page
	
	By loginPageHeading = By.xpath("//form[@class='login-form user-basic-info']/div/h4");
	By phoneNumberOrEmailId = By.xpath("//input[@aria-label='Phone Number / Email ID']");
	By hiddenPassword = By.xpath("//input[@aria-label='Enter Your Password' and @type='password']");
	By visiblePassword = By.xpath("//input[@aria-label='Enter Your Password' and @type='text']");
	By loginPasswordEye = By.xpath("//input[@aria-label='Enter Your Password']/../i");
	By loginButton = By.xpath("//button[@type='submit']");
	By loginFacebookButton = By.cssSelector("button.loginBtn.loginBtn--facebook");
	By loginGoogleButton = By.cssSelector("div.g-signin-button.loginBtn");
	By forgotPasswordLink = By.xpath("//a[contains(@href, '/user/forgotpassword')]");
	By helplineLink = By.xpath("//a[contains(@href, 'tel:+91-8033509035')]");
	By noUserAccountFound = By.xpath("//*[@class='snack__content']/h3");
	By phoneEmailErrorMessage = By.xpath("//input[@aria-label='Phone Number / Email ID']/..//following-sibling::div/div");
	By passwordErrorMessage = By.xpath("//input[@aria-label='Enter Your Password' and @type='password']/..//following-sibling::div/div");

	
	// Initializing the driver
	public LoginPage(WebDriver driver) {
	
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
	
	//Returning respective WebElements
	
	public String getLoginPageHeading()
	{
		return driver.findElement(loginPageHeading).getText();
	}	
	
	public WebElement getPhoneNumberOrEmailId()
	{
		return driver.findElement(phoneNumberOrEmailId);
	}	
	
	public WebElement getHiddenPassword()
	{
		return driver.findElement(hiddenPassword);
	}
	
	public WebElement getLoginPasswordEye()
	{
		return driver.findElement(loginPasswordEye);
	}
	
	public WebElement getVisiblePassword()
	{
		return driver.findElement(visiblePassword);
	}
	
	public WebElement getLoginButton()
	{
		return driver.findElement(loginButton);
	}

	public WebElement getLoginFacebookButton()
	{
		return driver.findElement(loginFacebookButton);
	}
	
	public WebElement getLoginGoogleButton()
	{
		return driver.findElement(loginGoogleButton);
	}
	
	public WebElement getForgotPasswordLink()
	{
		return driver.findElement(forgotPasswordLink);
	}
	
	public WebElement getHelplineLink()
	{
		return driver.findElement(helplineLink);
	}
	
	public WebElement getNoUserAccountFound()
	{
		return driver.findElement(noUserAccountFound);
	}
	
	public WebElement getPhoneEmailErrorMessage()
	{
		return driver.findElement(phoneEmailErrorMessage);
	}
	
	public WebElement getPasswordErrorMessage()
	{
		return driver.findElement(passwordErrorMessage);
	}
	
}
