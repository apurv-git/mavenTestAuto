package pageObject;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegistrationPage {

	public WebDriver driver;
	
	//All the WebElements for Registration Page
	
	By firstName = By.xpath("//input[@aria-label='First Name']");
	By lastName = By.xpath("//input[@aria-label='Last Name']");
	By emailId = By.xpath("//input[@aria-label='E-mail']");
	By mobileNumber = By.xpath("//input[@aria-label='Mobile Number (eg. 9876543210)' and @type='text']");
	By hiddenCreatePassword = By.xpath("//input[@aria-label='Create a Password' and @type='password']");
	By visibleCreatePassword = By.xpath("//input[@aria-label='Create a Password' and @type='text']");
	By createPasswordEye = By.xpath("//input[@aria-label='Create a Password']/../i");
	By medicalRegistrationNo = By.xpath("(//input[@aria-label='Medical Registration No'])[2]");
	By medicalCouncilDropDown = By.xpath("(//div[@class='menu']/../i)[2]");
	By policyCheckBox =  By.xpath("(//div[@class='input-group--selection-controls__ripple'])[2]");
	By registerButton = By.xpath("(//div[normalize-space(text()) = 'Register'])[2]");
	By welcomeMessage = By.cssSelector("div.flex.welcome-message>h4");
	By firstNameErrorMessage = By.xpath("//input[@aria-label='First Name']/..//following-sibling::div/div[1]");
	By lastNameErrorMessage = By.xpath("//input[@aria-label='Last Name']/..//following-sibling::div/div[1]");
	By emailIdErrorMessage = By.xpath("//input[@aria-label='E-mail']/..//following-sibling::div/div[1]");
	By mobileNumberErrorMessage = By.xpath("//input[@aria-label='Mobile Number (eg. 9876543210)' and @type='text']/..//following-sibling::div/div[1]");
	By hiddenCreatePasswordErrorMessage = By.xpath("//input[@aria-label='Create a Password' and @type='password']/..//following-sibling::div/div[1]");
	By medicalRegistrationNoErrorMessage = By.xpath("(//input[@aria-label='Medical Registration No'])[2]/..//following-sibling::div/div[1]");
	By dropDwonOptionBihar = By.xpath("(//div[normalize-space(text()) = 'Bihar' and @class='list__tile__title'])[2]");
	By optBox = By.xpath("(//input[@aria-label='Enter OTP'])[2]");
	By verifyButton = By.xpath("(//*[normalize-space(text()) = 'Verify'])[2]");
	By invalidOtpMessage = By.xpath("//*[normalize-space(text()) = 'OTP Invalid']");
	By duplicateUserErrorMessage = By.xpath("//*[@class='snack__content']");
	
	public RegistrationPage(WebDriver driver) {
	
		// TODO Auto-generated constructor stub
		this.driver = driver;
		
	}
	
	public WebElement getFirstName()
	{
		return driver.findElement(firstName);
	}	
	
	public WebElement getLastName()
	{
		return driver.findElement(lastName);
	}
	
	public WebElement getEmailId()
	{
		return driver.findElement(emailId);
	}

	public WebElement getMobileNumber()
	{
		return driver.findElement(mobileNumber);
	}
	
	public WebElement getHiddenCreatePassword()
	{
		return driver.findElement(hiddenCreatePassword);
	}
	
	public WebElement getCreatePasswordEye()
	{
		return driver.findElement(createPasswordEye);
	}
	
	public WebElement getVisibleCreatePassword()
	{
		return driver.findElement(visibleCreatePassword);
	}
	
	public WebElement getMedicalCouncilDropDown()
	{
		return driver.findElement(medicalCouncilDropDown);
	}
	
	public WebElement getPolicyCheckBox()
	{
		return driver.findElement(policyCheckBox);
	}
	
	public WebElement getRegisterButton()
	{
		return driver.findElement(registerButton);
	}
	
	public String getwelcomeMessage()
	{
		return driver.findElement(welcomeMessage).getText();
	}
	
	public WebElement getFirstNameErrorMessage()
	{
		return driver.findElement(firstNameErrorMessage);
	}
	
	public WebElement getLastNameErrorMessage()
	{
		return driver.findElement(lastNameErrorMessage);
	}
	
	public WebElement getEmailIdErrorMessage()
	{
		return driver.findElement(emailIdErrorMessage);
	}
	
	public WebElement getMobileNumberErrorMessage()
	{
		return driver.findElement(mobileNumberErrorMessage);
	}
	
	public WebElement getHiddenCreatePasswordErrorMessage()
	{
		return driver.findElement(hiddenCreatePasswordErrorMessage);
	}
	
	public WebElement getMedicalRegistrationNo()
	{
		return driver.findElement(medicalRegistrationNo);
	}
	
	public WebElement getMedicalRegistrationNoErrorMessage()
	{
		return driver.findElement(medicalRegistrationNoErrorMessage);
	}
	
	public WebElement getDropDwonOptionBihar()
	{
		return driver.findElement(dropDwonOptionBihar);
	}
	
	public WebElement getOptBox()
	{
		return driver.findElement(optBox);
	}
	
	public WebElement getVerifyButton()
	{
		return driver.findElement(verifyButton);
	}
	
	public WebElement getInvalidOtpMessage()
	{
		return driver.findElement(invalidOtpMessage);
	}
	
	public WebElement getDuplicateUserErrorMessage()
	{
		return driver.findElement(duplicateUserErrorMessage);
	}
	
	//Regex Patter Validation for Email Id
	
	public static final Pattern VALID_EMAIL_ADDRESS_REGEX = 
		    Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

		public static boolean validate(String emailStr) {
		        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX .matcher(emailStr);
		        return matcher.find();
		}
	
		public static String getAlphaNumericString(int n) 
	    { 
	  
	        // lower limit for LowerCase Letters 
	        int lowerLimit = 97; 
	  
	        // lower limit for LowerCase Letters 
	        int upperLimit = 122; 
	  
	        Random random = new Random(); 
	  
	        // Create a StringBuffer to store the result 
	        StringBuffer r = new StringBuffer(n); 
	  
	        for (int i = 0; i < n; i++) { 
	  
	            // take a random value between 97 and 122 
	            int nextRandomChar = lowerLimit 
	                                 + (int)(random.nextFloat() 
	                                         * (upperLimit - lowerLimit + 1)); 
	  
	            // append a character at the end of bs 
	            r.append((char)nextRandomChar); 
	        } 
	  
	        // return the resultant string 
	        return r.toString(); 
	    } 
	  
	
}