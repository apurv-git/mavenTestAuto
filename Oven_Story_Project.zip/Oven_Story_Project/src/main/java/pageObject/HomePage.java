package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

	public WebDriver driver;
	
	//All the webElement Locators for the Home Page
	
	By deliveryLocationTxtBox = By.id("locationSearchInput");
	By waitRandomModal = By.className("modalInner");
	By waitModalCloseMark = By.xpath("//div[@class='modalInner']/../span/span[@class='path1']");
	By homePageLogo = By.className("logoLink");	
	By offerPopUp = By.id("wzrk-cancel");
	By offerPopUpCancelBtn = By.id("wzrk-cancel");
	By vegSwitch = By.cssSelector("span.switchSlider.round");
	
	// Initializing the driver
	public HomePage(WebDriver driver) {
	
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
	
	//Returning respective WebElements
	
	public String getHomePageTitle()
	{
		return driver.getTitle();
	}	
	
	public WebElement getDeliveryLocationTxtBox()
	{
		return driver.findElement(deliveryLocationTxtBox);
	}	
	
	public WebElement getWaitRandomModal()
	{
		return driver.findElement(waitRandomModal);
	}	
	
	public WebElement getWaitModalCloseMark()
	{
		return driver.findElement(waitModalCloseMark);
	}
	
	public WebElement getHomePageLogo()
	{
		return driver.findElement(homePageLogo);
	}
	
	public WebElement getOfferPopUp()
	{
		return driver.findElement(offerPopUp);
	}
	
	public WebElement getOfferPopUpCancelBtn()
	{
		return driver.findElement(offerPopUpCancelBtn);
	}

	
}

