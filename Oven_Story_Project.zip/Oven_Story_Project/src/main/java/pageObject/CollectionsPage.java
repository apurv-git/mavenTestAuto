package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CollectionsPage {

	public WebDriver driver;
	
	//All the webElement Locators for the Collections Page

	//By vegSwitch = By.cssSelector("span.switchSlider.round");
	
	By vegSwitch = By.xpath("//*[@class='vegSwitch']/span");

	By checkCustomizationCheckBox= By.xpath("//input[@id='63027']/../span[contains(@class, 'checkboxUnselected')]");
	
	By unCheckCustomizationCheckBox= By.xpath("//input[@id='63027']/../span[contains(@class, 'checkboxSelected')]");
	
	By customiseNextButton = By.cssSelector("div.comboCustomisationSetChangeContainer>a");
	
	By checkoutButton = By.cssSelector("a#checkoutBtn");
	
	By menuItemName = By.xpath("//span[@class='cartProductNameInner']");
	
	By checkOutDetail = By.cssSelector("ul.checkoutDetail");
	
	By sideBar = By.cssSelector("span.icon-menu-font");
	
	By menuSideBar = By.cssSelector("li#sb_col>a");
	
	By partyOrdersSideBar = By.cssSelector("li#sb_po>a");
	
	By termsSideBar = By.cssSelector("li#sb_tr>a");
	
	By privacySideBar = By.cssSelector("li#sb_pr>a");
	
	By menuItemPage = By.cssSelector("div.collectionsWrapper");
	
	By partyOrderPage = By.cssSelector("main.partyOrdersPage");
	
	By termsPage = By.cssSelector("main.termsPage");
	
	By privacyPage = By.cssSelector("main.privacyPage");
	
	By locationHeader = By.cssSelector("div.locationHeader");
	
	
	By expandedSuggestion = By.xpath("//input[@id='locationSearchInput' and @aria-expanded='true']");
	
	

	
	// Initializing the driver
	public CollectionsPage(WebDriver driver) {
	
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
	
	//Returning respective WebElements
	
	public WebElement getVegSwitch()
	{
		return driver.findElement(vegSwitch);
	}	
	
	public WebElement getAddMenuItemButton(String menuItem)
	{  
				
		By addMenuItemButton = By.xpath("//*[@class='productName' and normalize-space(text())= '"+menuItem+"' ]/../../div/div/div/a");
		
		return driver.findElement(addMenuItemButton);
	}	
	
	public WebElement getCheckCustomizationCheckBox()
	{
		return driver.findElement(checkCustomizationCheckBox);
	}	
	
	public WebElement getUnCheckCustomizationCheckBox()
	{
		return driver.findElement(unCheckCustomizationCheckBox);
	}	
	
	public WebElement getCustomiseNextButton()
	{
		return driver.findElement(customiseNextButton);
	}
	
	public WebElement getcheckoutButton()
	{
		return driver.findElement(checkoutButton);
	}	
	
	public String getMenuItemName()
	{
		return driver.findElement(menuItemName).getText();
	}	
	
	public WebElement getSideBar()
	{
		return driver.findElement(sideBar);
	}	
	
	public WebElement getMenuSideBar()
	{
		return driver.findElement(menuSideBar);
	}	
	
	public WebElement getPartyOrdersSideBar()
	{
		return driver.findElement(partyOrdersSideBar);
	}	
	
	public WebElement getTermsSideBar()
	{
		return driver.findElement(termsSideBar);
	}	
	
	public WebElement getPrivacySideBar()
	{
		return driver.findElement(privacySideBar);
	}	
	
	public WebElement getMenuItemPage()
	{
		return driver.findElement(menuItemPage);
	}	
	
	public WebElement getCheckOutDetail()
	{
		return driver.findElement(checkOutDetail);
	}
	
	public WebElement getPrivacyPage()
	{
		return driver.findElement(privacyPage);
	}	
	
	
	public WebElement getTermsPage()
	{
		return driver.findElement(termsPage);
	}	
	
	
	public WebElement getPartyOrderPage()
	{
		return driver.findElement(partyOrderPage);
	}	
	
	public WebElement getlocationHeader()
	{
		return driver.findElement(locationHeader);
	}		
	
	public WebElement getSelectedLocationName(String locationName)
	{
		By selectedLocationName = By.xpath("//span[@class='locationNameHeader' and normalize-space(text())= '"+locationName+"']");
		return driver.findElement(selectedLocationName);
	}		
	
	public WebElement getExpandedSuggestion()
	{
		return driver.findElement(expandedSuggestion);
	}	
	
}

