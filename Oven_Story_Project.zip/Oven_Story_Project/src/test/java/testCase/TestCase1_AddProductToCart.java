package testCase;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.CollectionsPage;
import pageObject.HomePage;
import resources.Base;

public class TestCase1_AddProductToCart extends Base {	
	
	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  AddProductAfterLogin() throws IOException
	{
		
	}

	
	@Test
	public void  AddProductWithoutLogin() throws IOException, InterruptedException
	{


		// Implicit Wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		HomePage hp = new HomePage(driver);
		
		//Explicit Wait
		// Dynamic wait until the presence of Offers Pop Up
		WebDriverWait  d = new WebDriverWait(driver, 15);
		d.until(ExpectedConditions.visibilityOf(hp.getOfferPopUp()));
		hp.getOfferPopUpCancelBtn().click();
		
		//Explicit Wait
		// Dynamic wait until the presence of Text Box
		WebDriverWait  d1 = new WebDriverWait(driver, 5);
		d1.until(ExpectedConditions.visibilityOf(hp.getDeliveryLocationTxtBox()));
		
		
		// Assertion to Check whether the Text box is Displayed or Enabled
		Assert.assertTrue(hp.getDeliveryLocationTxtBox().isDisplayed());
		Assert.assertTrue(hp.getDeliveryLocationTxtBox().isEnabled());
		
		// Sending The Data in The Text Box
		hp.getDeliveryLocationTxtBox().sendKeys(prop.getProperty("testCase1_location"));	
		
		//Pressing Enter to Select the First value from Suggestions
		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ENTER);
		
		//OR
		
		// For Selecting the Value From Dynamic Drop Down 
		// For loop is used if our choice is coming after 4-5 options 
//		int i=1;
//		while(i<2)
//		{
//		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ARROW_DOWN);
//		i++;
//		}
//		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ENTER);
		
		
		// Waiting for the for the Selected Area Item to appear
		d.until(ExpectedConditions.visibilityOf(hp.getHomePageLogo()));
		
		
		//Select The Veg Menu
		//Creating Object to Access Collection Locators
		CollectionsPage cp = new CollectionsPage(driver);
//		d.until(ExpectedConditions.visibilityOf(cp.getVegSwitch()));
		cp.getVegSwitch().click();
		
		
		//Click on Add Button of Menu Item 
		
		String menuItem = prop.getProperty("testCase1_menuItemName");
		
		d.until(ExpectedConditions.visibilityOf(cp.getAddMenuItemButton(menuItem)));
				
		
		cp.getAddMenuItemButton(menuItem).click();
		
		Thread.sleep(5000);
		
		
		//Selecting the CustomiSation check Box
		cp.getCheckCustomizationCheckBox().click();
		
		//Selecting the Next Button
		cp.getCustomiseNextButton().click();
		
		//Selecting the Save Button
		cp.getCustomiseNextButton().click();
		
		//Checking the Item we selected is Ordered				
		Assert.assertEquals(cp.getMenuItemName(), prop.getProperty("testCase1_menuItemName"));
		
		//Clicking the Checkout Button
		cp.getcheckoutButton().click();
		
		//Waiting For Next Cart Page to Appear Mobile Number Field
		d.until(ExpectedConditions.visibilityOf(cp.getCheckOutDetail()));
		
		
		}
	

	}
	
	