package testCase;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.CollectionsPage;
import pageObject.HomePage;
import resources.Base;

public class TestCase3_ChangeLocationFromCollectionsPage extends Base {	
	
	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  verifyLocation() throws IOException
	{
		
	}

	
	@Test
	public void  changeLocation() throws IOException, InterruptedException
	{


		// Implicit Wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		HomePage hp = new HomePage(driver);
		
		//Explicit Wait
		// Dynamic wait until the presence of Offers Pop Up
		WebDriverWait  d = new WebDriverWait(driver, 15);
		d.until(ExpectedConditions.visibilityOf(hp.getOfferPopUp()));
		hp.getOfferPopUpCancelBtn().click();
		
		//Explicit Wait
		// Dynamic wait until the presence of Text Box
		WebDriverWait  d1 = new WebDriverWait(driver, 5);
		d1.until(ExpectedConditions.visibilityOf(hp.getDeliveryLocationTxtBox()));
		
		
		// Assertion to Check whether the Text box is Displayed or Enabled
		Assert.assertTrue(hp.getDeliveryLocationTxtBox().isDisplayed());
		Assert.assertTrue(hp.getDeliveryLocationTxtBox().isEnabled());
		
		// Sending The Data in The Text Box
		hp.getDeliveryLocationTxtBox().sendKeys(prop.getProperty("testCase1_location"));	
		

		
		//OR
		
		// For Selecting the Value From Dynamic Drop Down 
		// For loop is used if our choice is coming after 4-5 options 
//		int i=1;
//		while(i<2)
//		{
//		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ARROW_DOWN);
//		i++;
//		}
		
		//Creating Object to Access Collection Locators
		CollectionsPage cp = new CollectionsPage(driver);
		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ENTER);
		
		
		//Select Triple Side Bar
		d.until(ExpectedConditions.visibilityOf(cp.getlocationHeader()));
		cp.getlocationHeader().click();
		

		//Send New Location in the Text Box
		hp.getDeliveryLocationTxtBox().sendKeys(prop.getProperty("testCase3_location"));
		
		//Pressing Enter to Select the First value from Suggestions
		d.until(ExpectedConditions.visibilityOf(cp.getExpandedSuggestion()));
		
		//To Select The second Location
//		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ARROW_DOWN);
		
		//Pressing Enter to Select the First value from Suggestions
		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ENTER);
		
		//Waiting for the page to appear
		d.until(ExpectedConditions.visibilityOf(cp.getlocationHeader()));
		Assert.assertTrue(cp.getlocationHeader().isDisplayed());
		
		//Verifying First Selected Location is Displayed
		cp.getSelectedLocationName(prop.getProperty("testCase3_locationFullName")).isDisplayed();
	
	}
	

	}
	
	