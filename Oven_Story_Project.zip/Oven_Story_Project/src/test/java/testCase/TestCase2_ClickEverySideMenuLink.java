package testCase;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.CollectionsPage;
import pageObject.HomePage;
import resources.Base;

public class TestCase2_ClickEverySideMenuLink extends Base {	
	
	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();

	}
	
	@Test
	public void  performTaskOnEveryPage() throws IOException
	{
		
	}

	
	@Test
	public void  checkEveryPage() throws IOException, InterruptedException
	{


		// Implicit Wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
		HomePage hp = new HomePage(driver);
		
		//Explicit Wait
		// Dynamic wait until the presence of Offers Pop Up
		WebDriverWait  d = new WebDriverWait(driver, 15);
		d.until(ExpectedConditions.visibilityOf(hp.getOfferPopUp()));
		hp.getOfferPopUpCancelBtn().click();
		
		//Explicit Wait
		// Dynamic wait until the presence of Text Box
		WebDriverWait  d1 = new WebDriverWait(driver, 5);
		d1.until(ExpectedConditions.visibilityOf(hp.getDeliveryLocationTxtBox()));
		
		
		// Assertion to Check whether the Text box is Displayed or Enabled
		Assert.assertTrue(hp.getDeliveryLocationTxtBox().isDisplayed());
		Assert.assertTrue(hp.getDeliveryLocationTxtBox().isEnabled());
		
		// Sending The Data in The Text Box
		hp.getDeliveryLocationTxtBox().sendKeys(prop.getProperty("testCase1_location"));	
		
		//Pressing Enter to Select the First value from Suggestions
		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ENTER);
		
		//OR
		
		// For Selecting the Value From Dynamic Drop Down 
		// For loop is used if our choice is coming after 4-5 options 
//		int i=1;
//		while(i<2)
//		{
//		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ARROW_DOWN);
//		i++;
//		}
//		hp.getDeliveryLocationTxtBox().sendKeys(Keys.ENTER);
		
		
		// Waiting for the for the Selected Area Item to appear
		d.until(ExpectedConditions.visibilityOf(hp.getHomePageLogo()));
		
		
		//Select Triple Side Bar
		//Creating Object to Access Collection Locators
		CollectionsPage cp = new CollectionsPage(driver);
		d.until(ExpectedConditions.visibilityOf(cp.getSideBar()));
		cp.getSideBar().click();
		
		//Click on Menu Option
		cp.getMenuSideBar().click();
		
		//Wating for the page to appear
		d.until(ExpectedConditions.visibilityOf(cp.getMenuItemPage()));
		Assert.assertTrue(cp.getMenuItemPage().isDisplayed());
		

		//Click on Triple Side Bar
		cp.getSideBar().click();
		
		//Click on Party Order Option
		cp.getPartyOrdersSideBar().click();
		
		//Wating for the page to appear
		d.until(ExpectedConditions.visibilityOf(cp.getPartyOrderPage()));
		Assert.assertTrue(cp.getPartyOrderPage().isDisplayed());
		
		
		//Click on Triple Side Bar
		cp.getSideBar().click();
		
		//Click on Privacy Option
		cp.getPrivacySideBar().click();
		
		//Wating for the page to appear
		d.until(ExpectedConditions.visibilityOf(cp.getPrivacyPage()));
		Assert.assertTrue(cp.getPrivacyPage().isDisplayed());
		
		
		//Click on Triple Side Bar
		cp.getSideBar().click();
		
		//Click on Terms Option
		cp.getTermsSideBar().click();
		
		//Wating for the page to appear
		d.until(ExpectedConditions.visibilityOf(cp.getTermsPage()));
		Assert.assertTrue(cp.getTermsPage().isDisplayed());
		
		
		}
	

	}
	
	